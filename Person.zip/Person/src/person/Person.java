package person;
import java.util.*;
public class Person {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Properties pro = new Properties();
        System.out.print("Enter the gender: ");
        pro.Gender = sc.next();
        System.out.print("Enter the name: ");
        pro.name = sc.next();
        pro.Data();
    }
    
}
