package person;
public class Properties {
    String Gender;
    String name;
    public void Data(){
        System.out.println("the Gender of person is: "+Gender);
        System.out.println("the name of the person is: "+ name);
        Constructor construct = new Constructor();
    }
}
