package _12radiobuttonsapp;

/**
 *
 * @author INAM
 */
public class _12RadioButtonsApp 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        MetricConverter converter = new MetricConverter();
    
    }
    
}
