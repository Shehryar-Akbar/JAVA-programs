package WindowFrame;
import java.awt.*;
import javax.swing.*;
public class WindowFrame extends JFrame
{
    private JPanel panel1,panel2,panel3,panel4,panel5;                     // A holding panel
    private JLabel messageLabel;              // A message to the user
    private JRadioButton White;         // To hold user input
    private JRadioButton Wheat;
    private JRadioButton Brown;// To convert to miles
    private JRadioButton feetButton;          // To convert to feet
    private JRadioButton inchesButton;        // To convert to inches
    private ButtonGroup radioButtonGroup;
    
    public void WindowFrame()
    {
       // Set the title.
        setTitle("Metric Converter");
 
        // Set the size of the window.
        setSize(400, 400);
        
        // setting layout
        setLayout(new BorderLayout(5,10));
 
        // Specify an action for the close button.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        // Build the panel and add it to the frame.
        Panel_1();
 
        // Add the panel to the frame's content pane.
        add(panel1);
        // Display the window.
        setLocationRelativeTo(this);
        setVisible(true);
    }
    
    private void FixingLayout(){
        panel1 = new JPanel();
        panel1.setLayout(new GridLayout(3,1));
        White = new JRadioButton("White");
        Wheat = new JRadioButton("Wheat");
        Brown = new JRadioButton("Brown");
        
        panel1.add(White);
        panel1.add(Wheat);
        panel1.add(Brown);
        
        radioButtonGroup = new ButtonGroup();
        White = new JRadioButton("White");
        Wheat = new JRadioButton("Wheat");
        Brown = new JRadioButton("Brown");
    }
    
    //===================> FIRST PANEL
    
    private void Panel_1(){
        
    }
//    private void buildPanel()
//    {
//        // Create the label, text field, and radio buttons.
//        messageLabel = new JLabel("Enter a distance in kilometers");
//        kiloTextField = new JTextField(10);
//        milesButton = new JRadioButton("Convert to miles");
//        feetButton = new JRadioButton("Convert to feet");
//        inchesButton = new JRadioButton("Convert to inches");
// 
//        // Group the radio buttons.
//        radioButtonGroup = new ButtonGroup();
//        radioButtonGroup.add(milesButton);
//        radioButtonGroup.add(feetButton);
//        radioButtonGroup.add(inchesButton);
// 
//        // Add action listeners to the radio buttons.
//        milesButton.addActionListener(this);
//        feetButton.addActionListener(this);
//        inchesButton.addActionListener(this);
// 
//        // Create a panel and add the components to it.
//        panel = new JPanel();
//        panel.add(messageLabel);
//        panel.add(kiloTextField);
//        panel.add(milesButton);
//        panel.add(feetButton);
//        panel.add(inchesButton);
//    }
}
