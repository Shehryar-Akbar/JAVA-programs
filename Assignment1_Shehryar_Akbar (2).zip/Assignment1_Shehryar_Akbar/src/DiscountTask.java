import java.util.Scanner;
public class DiscountTask {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter the number of packages: ");
    int num = sc.nextInt();
    if(num>=1 && num<10)
    {
	int pay = num*99;
	System.out.println("Sorry ther is no discount on quantity less than 10");
	System.out.println("The payable amount is "+ (pay));
    }
    if(num>=10 && num<=19)
    {
        int AmountBefore = num*99;
        float Discount = ((float)AmountBefore/100)*20;
        float ActualAmount = AmountBefore-Discount;
        System.out.println("Original amount "+ AmountBefore);
	System.out.println("Discount for you is "+ Discount);
	System.out.println("The payable amount is "+ (ActualAmount));
    }
    if(num>=20 && num<=49)
    {
	int AmountBefore = num*99;
	float Discount = ((float)AmountBefore/100)*30;
	float ActualAmount = AmountBefore-Discount;
	System.out.println("Original amount "+ AmountBefore);
	System.out.println("Discount for you is "+ Discount);
	System.out.println("The payable amount is "+ (ActualAmount));
    }
    if(num>=50 && num<=99)
    {
        int AmountBefore = num*99;
	float Discount = ((float)AmountBefore/100)*40;
	float ActualAmount = AmountBefore-Discount;
	System.out.println("Original amount "+ AmountBefore);
	System.out.println("Discount for you is "+ Discount);
	System.out.println("The payable amount is "+ (ActualAmount));
    }
    if(num>=100)
    {
	int AmountBefore = num*99;
	float Discount = ((float)AmountBefore/100)*50;
	float ActualAmount = AmountBefore-Discount;
	System.out.println("Original amount "+ AmountBefore);
	System.out.println("Discount for you is "+ Discount);
	System.out.println("The payable amount is "+ (ActualAmount));
    }	
    }
}
