import java.util.Scanner;
public class BankAccount {
    public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.print("Enter the account number: ");
    long Account = sc.nextLong();
    System.out.print("Enter the latter c or s for the type of account (c = current and s = saving): ");
    char ch = sc.next().charAt(0);
    System.out.print("Enter the minimum balance: ");
    long MinimumBalance = sc.nextLong();
    System.out.print("Enter the current balance: ");
    long CurrentBalance = sc.nextLong();
    if(ch=='s' || ch=='S') {
	if(CurrentBalance < MinimumBalance) {
            long Charge = CurrentBalance-10;
            System.out.println("Your balance is less then minimum balance there for $10 have cut from your balance");
            System.out.println("Your balance is: "+ Charge);
	}
        else {
            double Interest = CurrentBalance*0.04;
            System.out.println("Your balance with 4% interest is: "+Interest);
	}
    }
    if(ch=='c' || ch=='C'){
	if(CurrentBalance < MinimumBalance) {
	long Charge = CurrentBalance-25;
	System.out.println("Your balance is less then minimum balance therefore $25 have cut from your balance");
	System.out.println("Your balance is: "+ Charge);
        }
        else {
            if(CurrentBalance <= MinimumBalance+5000){
               double Interest = CurrentBalance*0.03;
               System.out.println("The Balance is: "+(CurrentBalance+Interest));
            }
            else{
                double Interest = CurrentBalance*0.05;
                System.out.println("Your balance is: "+(CurrentBalance+Interest));
            }
	}
        }
    }
}
