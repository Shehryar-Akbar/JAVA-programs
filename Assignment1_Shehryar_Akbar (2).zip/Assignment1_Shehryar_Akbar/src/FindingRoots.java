import java.util.Scanner;
public class FindingRoots {
 public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the value of a ");
    double a = sc.nextInt();
    System.out.println("Enter the value of b ");
    double b = sc.nextInt();
    System.out.println("Enter the value of c ");
    double c = sc.nextInt();
    double Determinant = b * b - 4 * a * c;
    if(Determinant>0) {
        System.out.println("The roots are real and may positive or negative ");
	double root1 = (-b + Math.sqrt(Determinant))/(2*a);
	double root2 = (-b - Math.sqrt(Determinant))/(2*a);
	System.out.println("Root-1 = "+root1);
	System.out.println("Root-2 = "+root2);
    }
    if(Determinant<0) {
	System.out.print("The roots are complex ");
    }
    if(Determinant==0) {
        System.out.println("the roots are equal and real ");
        double r = -b/2*a;
        System.out.print("Root: "+r);
    }
  }   
}
