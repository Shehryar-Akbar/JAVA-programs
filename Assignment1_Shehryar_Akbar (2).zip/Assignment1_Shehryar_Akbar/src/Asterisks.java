 import java.util.*;
public class Asterisks {
	public static void main(String[] args)
	{
		int [] arr = new int[5];
		Scanner sc = new Scanner(System.in);	
		System.out.println("Remember that the sale must be multiple of 100\n");
		for (int i=0; i<5; i++)
		{
			System.out.print("Enter today's sales for store " + (i+1) + ": ");
			arr[i] = sc.nextInt();
		}
		System.out.println("SALES BAR CHART");
		for(int i=0; i<5; i++)
		{
			System.out.print("Store "+ (i+1) + ": ");
			int n2 = arr[i]/100;
			for(int j=0; j<n2; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}	
	}
}
