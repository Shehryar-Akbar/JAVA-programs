package _13checkboxesdemo;

/**
 *
 * @author INAM
 */
public class _13CheckBoxesDemo 
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        ColorCheckBoxWindow window = new ColorCheckBoxWindow();
    }
    
}
