import java.util.Scanner;
public class TimeCalculator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
	System.out.print("Enter the word Water or Steel or Air to calculate the time ");
	String str = sc.next(); 
	switch(str){
            case "water":{
                System.out.print("Enter the distance traviled ");
                float Spd = sc.nextFloat();
                float Time = (float) (Spd/4900); 
                System.out.println("Time :" + Time+ " sec");
                break;
            }
            case "air":{
                System.out.print("Enter the distance traviled ");
                float Spd = sc.nextFloat();
                float Time = (float)(Spd/1100); 
                System.out.println("Time :" + Time+ " sec");
                break;
	    }
            case "steel":{
                System.out.print("Enter the distance traviled ");
                float Spd = sc.nextFloat();
		float Time = (float)(Spd/16400); 
		System.out.println("Time :" + Time+ " sec");
		break;
            }
	} 	
    }
}
