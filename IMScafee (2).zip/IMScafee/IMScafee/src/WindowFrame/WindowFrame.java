package WindowFrame;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.*;
public class WindowFrame extends JFrame 
{
    private JPanel panel1,panel2,panel3,panel4,panel5;                     // A holding panel              // A message to the user
    private JRadioButton White;         // To hold user input
    private JRadioButton Wheat;
    private JRadioButton Brown;// To convert to miles
    private JCheckBox Cream_Cheese, Butter, Peach_jelly, Blueberry_jam;
    private JRadioButton None;          // To convert to feet
    private JRadioButton Regular_coffee;        // To convert to inches
    private JRadioButton Decaf_coffee;
    private JRadioButton Cappuccino;
    private ButtonGroup radioButtonGroup1;
    private ButtonGroup radioButtonGroup2;
    private JButton btn1,btn2;
    private double white,wheat,brown;
    private double non, cof2, cof3, cof4;
    private double top1,top2,top3,top4;
    
    public void WindowFrame()
    {
       // Set the title.
        setTitle("Metric Converter");
 
        // Set the size of the window.
        setSize(350, 350);
        
        // setting layout
        setLayout(new BorderLayout(10,10));
 
        // Specify an action for the close button.
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        // Build the panel and add it to the frame.
//        Panel_1();
        Panel_1 pan1 = new Panel_1();
        Panel_2 pan2 = new Panel_2();
        Panel_3 pan3 = new Panel_3();
        Panel_4 pan4 = new Panel_4();
        Panel_5 pan5 = new Panel_5();
 
        // Add the panel to the frame's content pane.
        add(panel1, BorderLayout.NORTH);
        add(panel2, BorderLayout.WEST);
        add(panel3, BorderLayout.CENTER);
        add(panel4, BorderLayout.EAST);
        add(panel5, BorderLayout.SOUTH);
        // Display the window.
        setLocationRelativeTo(this);
        setVisible(true);
    }
    //================> FIRST PANEL
    private class Panel_1
    {
        public Panel_1(){
            panel1 = new JPanel();
            panel1.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 20));
            panel1.setBorder(BorderFactory.createTitledBorder(""));
            JLabel lab = new JLabel("Welcome to IMCafee");
            panel1.add(lab);
        }
        
    }
    //===================> SECOND PANEL
    private class Panel_2 implements ActionListener
    {
        public Panel_2()
        {
            panel2 = new JPanel();
            panel2.setBorder(BorderFactory.createTitledBorder("Bagal"));
            panel2.setLayout(new GridLayout(3,1));
            White = new JRadioButton("White");
            Wheat = new JRadioButton("Wheat");
            Brown = new JRadioButton("Brown");

            radioButtonGroup1 = new ButtonGroup();
            radioButtonGroup1.add(White);
            radioButtonGroup1.add(Wheat);
            radioButtonGroup1.add(Brown);
            
            White.addActionListener(this);
            Wheat.addActionListener(this);
            Brown.addActionListener(this);

            panel2.add(White);
            panel2.add(Wheat);
            panel2.add(Brown);
        }    

        @Override
        public void actionPerformed(ActionEvent ae) {
           if(ae.getSource() == White){
               white = 10;
               System.out.println(white);
           }
           else if(ae.getSource() == Wheat){
               wheat = 20;
           }
           else if(ae.getSource() == Brown){
               brown = 30;
           }
        }
    }
    
   //===================> THIRD PANEL
    
    private class Panel_3 implements ItemListener
    {
        public Panel_3()
        {
            panel3 = new JPanel();
            panel3.setBorder(BorderFactory.createTitledBorder("Toppings"));
            panel3.setLayout(new GridLayout(4,1));
            Cream_Cheese = new JCheckBox("Cream cheese");
            Butter = new JCheckBox("Butter");
            Peach_jelly = new JCheckBox("Peach jelly");
            Blueberry_jam = new JCheckBox("Blueberry jam");
            
            Cream_Cheese.addItemListener(this);
            Butter.addItemListener(this);
            Peach_jelly.addItemListener(this);
            Blueberry_jam.addItemListener(this);

            panel3.add(Cream_Cheese);
            panel3.add(Butter);
            panel3.add(Peach_jelly);
            panel3.add(Blueberry_jam);
        }

        @Override
        public void itemStateChanged(ItemEvent ie) {
            if(ie.getSource() == Cream_Cheese)
            {
                if(Cream_Cheese.isSelected())
                {
                    top1 = 30;  
                    System.out.println(top1);
                }
                else
                {
                    top1 = 0;
                }
            }
            if(ie.getSource() == Butter)
            {
                if(Butter.isSelected())
                {
                    top2 = 40;                  
                }
                else
                {
                    top2 = 0;
                }
            }
            if(ie.getSource() == Peach_jelly)
            {
                if(Peach_jelly.isSelected())
                {
                    top3 = 50;                  
                }
                else
                {
                    top3 = 0;
                }
            }
            if(ie.getSource() == Blueberry_jam)
            {
                if(Blueberry_jam.isSelected())
                {
                    top4 = 60;                  
                }
                else
                {
                    top4 = 0;
                }
            }
            
        }
    }
    //============================> FOURTH PANEL
    private class Panel_4 implements ActionListener 
    {
        public Panel_4()
        {
            panel4 = new JPanel();
            panel4.setBorder(BorderFactory.createTitledBorder("Bagal"));
            panel4.setLayout(new GridLayout(4,1));
            None = new JRadioButton("None");
            Regular_coffee = new JRadioButton("Regular coffee");
            Decaf_coffee = new JRadioButton("Decaf coffee");
            Cappuccino = new JRadioButton("Cappuccino");


            radioButtonGroup2 = new ButtonGroup();
            radioButtonGroup2.add(None);
            radioButtonGroup2.add(Regular_coffee);
            radioButtonGroup2.add(Decaf_coffee);
            radioButtonGroup2.add(Cappuccino);
        
            None.addActionListener(this);
            Regular_coffee.addActionListener(this);
            Decaf_coffee.addActionListener(this);
            Cappuccino.addActionListener(this);
            
            panel4.add(None);
            panel4.add(Regular_coffee);
            panel4.add(Decaf_coffee);
            panel4.add(Cappuccino);
        
        }

        @Override
        public void actionPerformed(ActionEvent ae) {
           if(ae.getSource() == None){
               non = 0;   
           }
           else if(ae.getSource() == Regular_coffee){
               cof2 = 60;
               System.out.println(cof2);
           }
           else if(ae.getSource() == Decaf_coffee){
               cof3 = 80;
           }
           else if(ae.getSource() == Cappuccino){
               cof4 = 90;
           }
        }
    }
    
    //=====================>  FIFTH PANEL
    
    private class Panel_5 implements ActionListener
    {
        private JFrame frame;
        private JLabel lab1,lab2,lab3;
        private JButton btn;
        public Panel_5()
        {
            
            
            btn1 = new JButton("Calculate");
            btn2 = new JButton("Exit");
            panel5 = new JPanel();
            panel5.setLayout(new FlowLayout(FlowLayout.CENTER, 5,10));
            
            btn1.addActionListener(this);
            btn2.addActionListener(this);
            panel5.add(btn1);
            panel5.add(btn2);
        }
        
        @Override
        public void actionPerformed(ActionEvent ae){
            
            if(ae.getSource() == btn1){
                double result;
                result = white+wheat+brown+non+cof2+cof3+cof4+top1+top2+top3+top4;
                System.out.println(result);
                
                frame = new JFrame("RESULT TAB");
                frame.setSize(200, 200);
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLayout(new GridLayout(3,1));
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
                
                lab1 = new JLabel("total amoutn:  "+result);
                lab2 = new JLabel("Taxt is : 13.5");
                lab3 = new JLabel("Payable amount: "+(result+13.5));
                
                frame.add(lab1);
                frame.add(lab2);
                frame.add(lab3);
                
            }
            else if(ae.getSource() == btn2){
               // frame.despose();
            }
        }
    }
}