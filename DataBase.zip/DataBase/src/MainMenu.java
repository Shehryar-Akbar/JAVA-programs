import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.*;

public class MainMenu implements ActionListener{
    
    private JFrame frame = new JFrame();
    private JPanel panel;
    private JTextField field1,field2,field3;
    private JLabel lab1;
    private JLabel lab2;
    private JLabel lab3;
    private JButton but;
    private String s1,s2,s3;
    private Statement stm;
    private Connection con;
    private String sqlStatement;
    private int id;
    private int rows;
    
   public MainMenu() {
        
        panel = new JPanel();
        frame.setSize(1000,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.add(panel);

        lab1 = new JLabel("ID");
        lab1.setBounds(12, 7, 20, 50);
        lab1.setVisible(true);
        panel.add(lab1);

        field1 = new JTextField(5);
        field1.setBounds(50, 10, 100, 50);
        s1 = field1.getText();
        id = Integer.parseInt(s1);
        panel.add(field1);

        lab2 = new JLabel("FR_NAME");
        lab2.setBounds(12, 7, 50, 60);
        lab2.setVisible(true);
        panel.add(lab2);

        field2 = new JTextField(20);
        field2.setBounds(50, 10, 100, 100);
        s2 = field2.getText();
        field2.setVisible(true);
        panel.add(field2);

        lab3 = new JLabel("LAS_NAME");
        lab3.setBounds(12, 7, 50, 90);
        lab3.setVisible(true);
        panel.add(lab3);

        field3 = new JTextField(20);
        field3.setBounds(50, 10, 100, 150);
        s3 = field3.getText();
        field3.setVisible(true);
        panel.add(field3);

        but = new JButton("Submit");
        but.setFocusable(false);
        but.setBounds(200, 100, 100, 250);
        but.addActionListener(this);
        but.setVisible(true);

        panel.add(but);
        panel.setVisible(true);
        
        try{
                String host = "jdbc:derby://localhost:1527/MySchool";
                String uName = "principal";
                String uPass = "akbar"; 

                con = DriverManager.getConnection(host, uName, uPass);

                stm = con.createStatement();

                sqlStatement = "INSERT INTO  FIRSTCLASS" +"(ID,FR_NAME, LAS_NAME)" 
                        + "VALUES ('" + id + "', "+ s2 + ", '" + s3 + "')";
            }
        catch (SQLException err) {
             System.out.println( err.getMessage( ) );
    }
 }

    @Override
     public void actionPerformed(ActionEvent ae) {
        if(ae.getSource() == but){
            try {
                rows = stm.executeUpdate(sqlStatement);
                con.close();
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
   }
}