
public class MainClass {
    public static void main(String[] args){
        MainMenu menu = new MainMenu();
    }
}