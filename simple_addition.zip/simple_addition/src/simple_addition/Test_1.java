package simple_addition;
import java.util.Scanner;

public class Test_1 {
    public static void main(String args[]){
        Test_2 obj1 = new Test_2();
        obj1.Output();
    }
}

class Test_2 {
    Test_3 obj2 = new Test_3();
    public void Output(){
        obj2.Add();
    }
}

class Test_3 {
    private int a,b;
    private int sum;
    Scanner input = new Scanner(System.in);
    public void Add(){
        System.out.print("Enter the first number: ");
        a = input.nextInt();
        System.out.print("Enter the second number: ");
        b = input.nextInt();
        sum = a + b;
        System.out.println("The sum of the number is: "+sum);
    }   
}