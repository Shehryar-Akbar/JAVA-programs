package pkg01_hilowgame;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;


public class GameBoard extends JFrame
{
    private static final int FRAME_WIDTH = 250;
    private static final int FRAME_HEIGHT = 270;
    private static final int FRAME_X_ORIGIN = 150;
    private static final int FRAME_Y_ORIGIN = 250;
    private JPanel guessPanel, hintPanel, controlPanel, buttonPanel;
    private JButton enterBtn, cancelBtn;
    private Random random;
    
    private final String ENTER = "Enter";
    private final String CANCEL = "Cancel";
//    private final String BLANK = "";
    private JTextField guessEntry;
    private JLabel hint;
    private Container contentPane;
//    String s;
    public GameBoard()
    {
        
        
 
        guessEntry = new JTextField(10);
        
  //==================================
  
        setSize(FRAME_WIDTH, FRAME_HEIGHT);
        setTitle("NUMBER GAME");
        setLocation(FRAME_X_ORIGIN, FRAME_Y_ORIGIN);
        
        contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(3,1));
        
        guessPanel = new JPanel();
        guessPanel.setBorder(BorderFactory.createTitledBorder("Your Guess"));
        guessPanel.add(guessEntry);
        
        hintPanel = new JPanel();
        hintPanel.setBorder(BorderFactory.createTitledBorder("Hint"));
        hintPanel.add(hint = new JLabel("Let's Play the Game"));
        
        controlPanel = new JPanel(new BorderLayout());
        buttonPanel = new JPanel();
        buttonPanel.add(enterBtn = new JButton(ENTER));
        buttonPanel.add(cancelBtn = new JButton(CANCEL));
        enterBtn.addActionListener(new ButtonListener());
        cancelBtn.addActionListener(new ButtonListener());
        
        
        controlPanel.add(buttonPanel, BorderLayout.SOUTH);
       
        contentPane.add(guessPanel);
        contentPane.add(hintPanel);
        contentPane.add(controlPanel);
        
    }

    public class ButtonListener implements ActionListener
    {
    @Override
    public void actionPerformed(ActionEvent ae) {
            String s = guessEntry.getText();
            random = new Random(100);
            int R = random.nextInt(100-0) + 0;
            int num = Integer.parseInt(s);
        if (ae.getSource() == enterBtn )
        {
            if(num == R){
                hint.setText("you wing the game");   
            }
            if(num > R){
               hint.setText("The number is high");
            }
            if(num < R){
               hint.setText("The number is too low");
            }
        }
        
        if(ae.getSource() == cancelBtn ){
            System.exit(0);
        }
    }
    
}
}