package dogs;
import java.util.*;
public class Dogs {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Properties dg = new Properties();
        System.out.println("Enter the gender of the dog: ");
        dg.Gender = sc.next();
        System.out.println("Enter the name of the dog: ");
        dg.name = sc.next();
        System.out.println("Enter the age of the dog: ");
        dg.age = sc.nextInt();
        dg.prop();
    }
    
}
