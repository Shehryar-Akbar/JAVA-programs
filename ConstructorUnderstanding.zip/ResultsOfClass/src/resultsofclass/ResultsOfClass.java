package resultsofclass;
import java.util.*;

public class ResultsOfClass 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Random r = new Random();
        int count = 0;
        System.out.print("enter the num of students: ");
        int opt = sc.nextInt();
        int Marks[] = new int[opt];
        for(int i=0; i<Marks.length; i++)
        {
            int rand = r.nextInt(101);
            Marks[i] = rand;
        }
        for(int i=0; i<Marks.length; i++)
        {
            System.out.print(Marks[i]+"  ");
        }
        System.out.println();
        System.out.println("Marks Status: ");
        int freq[] = new int[10];
        for(int i=0; i<Marks.length; i++)
        {
            if(Marks[i]>=0 && Marks[i]<=9)
            {
                freq[0]++;
            }
            else if(Marks[i]>=10 && Marks[i]<=19)
            {               
                freq[1]++;
            }
            
            else if(Marks[i]>=20 && Marks[i]<=29)
            {               
                freq[2]++;
            }
            else if(Marks[i]>=30 && Marks[i]<=39)
            {               
                freq[3]++;
            }
            
            else if(Marks[i]>=40 && Marks[i]<=49)
            {               
                freq[4]++;
            }
            
            else if(Marks[i]>=50 && Marks[i]<=59)
            {               
                freq[5]++;
            }
            
            else if(Marks[i]>=60 && Marks[i]<=69)
            {               
                freq[6]++;
            }
           
            else if(Marks[i]>=70 && Marks[i]<=79)
            {               
                freq[7]++;
            }
            else if(Marks[i]>=80 && Marks[i]<=89)
            {               
                freq[8]++;
            }
            else if(Marks[i]>=90 && Marks[i]<=100)
            {               
                freq[9]++;
            }     
        }
        for(int i=0; i<freq.length; i++){
                System.out.print(freq[i]+" ");
            }
        System.out.println();
        System.out.println("Grade distribution: ");
        int b = 9;
        for(int i=0; i<freq.length; i++)
        {
            System.out.print(i+"-"+b+": ");
            b+=10;
            for (int j=0; j<freq[i]; j++){
            System.out.print("* ");
            }
            System.out.println();
        }
        
    }  
}
