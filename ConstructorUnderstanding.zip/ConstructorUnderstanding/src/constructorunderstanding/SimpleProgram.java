
package constructorunderstanding;

public class SimpleProgram {
   //======== CONSTRUCTOR =========//
    public SimpleProgram(){
        int x=20, y=50;
        System.out.println("the sum of the numbers is: "+(x+y));
        System.out.println("the diff of the numbers is: "+(x-y));
        System.out.println("the multiplication of the numbers is: "+(x*y));
        int a=50,b=10;
        System.out.println("the division of the numbers is: "+(a/b));
    }
        
}
