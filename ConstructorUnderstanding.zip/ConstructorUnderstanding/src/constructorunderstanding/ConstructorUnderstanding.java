
package constructorunderstanding;

public class ConstructorUnderstanding {

    public static void main(String[] args) {
        SimpleProgram simple = new SimpleProgram();
    }
    
}
