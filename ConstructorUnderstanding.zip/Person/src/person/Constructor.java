package person;
import java.util.Random;
import java.util.Scanner;

public class Constructor {
    public Constructor(){
        Random rand = new Random();
        long num = rand.nextInt(100);
        System.out.println("Your ID is: "+num);
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the class that you will be teaching to: ");
        int cls = sc.nextInt();
        if(cls>=1 && cls<3){
            System.out.println("your salary is: 6000");
        }
        if(cls>=3 && cls<6){
            System.out.println("your salary is: 9000");
        }
    }
}
