package task.using.border.layout;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

class SubClass
{
    JFrame frame = new JFrame();
    JButton btn1, btn2, btn3, btn4, btn5, btn6;
    JPanel pan1 = new JPanel();
    JPanel pan2 = new JPanel();
    
    public void display()
    {
        frame.setSize(550,90);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(5,10));
        //====================================//
        btn1 = new JButton("Button 1");
        btn1.setFocusable(false);//----------> this method removes the focussing form the button
        btn2 = new JButton("Button 2");
        btn2.setFocusable(false);
        btn3 = new JButton("Button 3");
        btn3.setFocusable(false);
        btn4 = new JButton("Button 4");
        btn4.setFocusable(false);
        btn5 = new JButton("Button 5");
        btn5.setFocusable(false);
        btn6 = new JButton("Button 6");
        btn6.setFocusable(false);
        //===================================//
        pan1.setLayout(new FlowLayout(FlowLayout.LEFT,5,10));
        pan1.add(btn1);
        pan1.add(btn2);
        pan1.add(btn3);
        //===================================//
        pan2.setLayout(new FlowLayout(FlowLayout.RIGHT,5,10));
        pan2.add(btn4);
        pan2.add(btn5);
        pan2.add(btn6);
        
        pan1.add(pan2);
        //==================================//
        frame.add(pan1, BorderLayout.SOUTH);

        frame.setVisible(true);
    }
}
public class TaskUsingBorderLayout {

    public static void main(String[] args) {
        SubClass obj = new SubClass();
        obj.display();
    }
    
}
