package fixcing.buttons.on.a.frame;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

class SubClass
{
    JFrame frame = new JFrame();
    JButton btn1, btn2, btn3, btn4, btn5, btn6;
    JPanel pan1 = new JPanel();
    JPanel pan2 = new JPanel();
    JPanel pan3 = new JPanel();
    JPanel pan4 = new JPanel();
    JPanel pan5 = new JPanel();
    JPanel pan6 = new JPanel();
    
    
    
    public void display()
    {
        frame.setSize(300,130);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(2,3,5,10));
        //====================================//
        btn1 = new JButton("Button 1");
        btn1.setFocusable(false);//----------> this method removes the focussing form the button
        btn2 = new JButton("Button 2");
        btn2.setFocusable(false);
        btn3 = new JButton("Button 3");
        btn3.setFocusable(false);
        btn4 = new JButton("Button 4");
        btn4.setFocusable(false);
        btn5 = new JButton("Button 5");
        btn5.setFocusable(false);
        btn6 = new JButton("Button 6");
        btn6.setFocusable(false);
        //===================================//
        pan1.add(btn1);
        pan2.add(btn2);
        pan3.add(btn3);
        //===================================//
        pan4.add(btn4);
        pan5.add(btn5);
        pan6.add(btn6);
        //==================================//
        frame.add(pan1);
        frame.add(pan2);
        frame.add(pan3);
        frame.add(pan4);
        frame.add(pan5);
        frame.add(pan6);
        frame.setVisible(true);
    }
}
public class FixcingButtonsOnAFrame {

    public static void main(String[] args) {
        SubClass obj = new SubClass();
        obj.display();
    }
    
}
