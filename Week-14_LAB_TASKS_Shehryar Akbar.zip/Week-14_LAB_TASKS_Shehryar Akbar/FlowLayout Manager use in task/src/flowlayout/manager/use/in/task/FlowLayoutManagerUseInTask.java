package flowlayout.manager.use.in.task;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

class SubClass
{
    JFrame frame = new JFrame();
    JButton btn1, btn2, btn3, btn4, btn5, btn6;
    JPanel pan1 = new JPanel();
    JPanel pan2 = new JPanel();
    
    public void display()
    {
        frame.setSize(600,100);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());
        //====================================//
        btn1 = new JButton("Button 1");
        btn2 = new JButton("Button 2");
        btn3 = new JButton("Button 3");
        btn4 = new JButton("Button 4");
        btn5 = new JButton("Button 5");
        btn6 = new JButton("Button 6");
        //===================================//
        pan1.setLayout(new FlowLayout(FlowLayout.CENTER,10,5));
        pan1.add(btn1);
        pan1.add(btn2);
        pan1.add(btn3);
        //===================================//
        pan2.setLayout(new FlowLayout(FlowLayout.CENTER,10,5));
        pan2.add(btn4);
        pan2.add(btn5);
        pan2.add(btn6);
        //==================================//
        frame.add(pan1);
        frame.add(pan2);
    }
}

public class FlowLayoutManagerUseInTask {
    public static void main(String[] args) {
        SubClass obj = new SubClass();
        obj.display();
    }
    
}


