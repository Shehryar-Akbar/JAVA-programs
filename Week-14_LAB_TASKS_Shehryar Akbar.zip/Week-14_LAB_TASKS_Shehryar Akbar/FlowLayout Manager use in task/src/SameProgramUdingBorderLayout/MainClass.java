package SameProgramUdingBorderLayout;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

class SubClass
{
    JFrame frame = new JFrame();
    JButton btn1, btn2, btn3, btn4, btn5, btn6;
    JPanel pan1 = new JPanel();
    JPanel pan2 = new JPanel();
    
    public void display()
    {
        frame.setSize(600,80);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout(5,10));
        //====================================//
        btn1 = new JButton("Button 1");
        btn2 = new JButton("Button 2");
        btn3 = new JButton("Button 3");
        btn4 = new JButton("Button 4");
        btn5 = new JButton("Button 5");
        btn6 = new JButton("Button 6");
        //===================================//
        pan1.setLayout(new FlowLayout(FlowLayout.CENTER,10,5));
        pan1.add(btn1);
        pan1.add(btn2);
        pan1.add(btn3);
        //===================================//
        pan2.setLayout(new FlowLayout(FlowLayout.CENTER,10,5));
        pan2.add(btn4);
        pan2.add(btn5);
        pan2.add(btn6);
        //==================================//
        frame.add(pan1, BorderLayout.SOUTH);
        frame.add(pan2, BorderLayout.CENTER);
    }
}

public class MainClass 
{
    public static void amin(String[] args)
    {
        SubClass obj = new SubClass();
        obj.display();
    }
}
/* (Use the BorderLayout manager) Rewrite the preceding program to create the same user interface, but
instead of using FlowLayout for the frame, use BorderLayout. Place one panel in the south of the frame
and the other in the center.
(Use the GridLayout manager) Rewrite Programming Exercise 1 to add six buttons into a frame. Use a
GridLayout of two rows and three columns for the frame.
(Use JPanel to group buttons) Rewrite Programming Exercise 1 to create the same user interface. Instead
of creating buttons and panels separately, define a class that extends the JPanel class. Place three buttons
in your panel class, and create two panels from the user-defined panel class.*/