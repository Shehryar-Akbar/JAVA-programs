package square.matrix;

import java.awt.*;
import java.util.Random;
import javax.swing.*;

class Subclass{
    
    private JFrame frame = new JFrame("Showing the 0 and 1 square matrix");
    private JPanel panel[] = new JPanel[100];
    
    public void display(){ 
        frame.setSize(300,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new GridLayout(10,10,5,5));
    
        Random random = new Random();
        int rand;
        for(int i = 0; i<100; i++){
            rand = random.nextInt();
            panel[i] = new JPanel();
            if(rand > 0.5838383){
                panel[i].add(new JLabel(""+(1)));
            }
            else{
                panel[i].add(new JLabel(""+(0)));
            }
            frame.add(panel[i]);
        }
    }
}
public class SquareMatrix {

    public static void main(String[] args) {
        Subclass obj = new Subclass();
        obj.display();
    } 
}
