package dogs;
public class Properties {
    String Gender;
    String name;
    int age;
    public Properties(){
        System.out.println("the gender of the dog is: "+Gender);
        System.out.println("The name of the dog is: "+name);
        System.out.println("The age of the dog is: "+age);  
    }
    public void prop(){
        System.out.println("=====================================");
        System.out.println("=====================================");
        System.out.println("this dog can run");
        System.out.println("This dog can sit");
        System.out.println("This dog can sang");
    }
}
