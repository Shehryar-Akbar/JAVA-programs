/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfor.the.presentation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Shehryar Akbar
 */
public class Creating_column {
    
    private String host = "jdbc:derby://localhost:1527/DEMO";
    private String uName = "demo";
    private String uPass = "demo"; 
    
    public void Column(){
        try{
            
      //====================> connection with the database <======================\\      
            Connection con = DriverManager.getConnection(host, uName, uPass);
            System.out.println("connection succeeded");
         
      //====================> creating statement <======================\\
            Statement stmt = con.createStatement();
          
      //====================> WRITING QUERY <======================\\
            String query = "alter table DEMO add GPA DOUBLE";
          
      //====================> EXECUTING QUERY <======================\\      
            int result = stmt.executeUpdate(query);
        
      //===================> FOR CHECKING <============= BUT IT HAS A PROBLEM      
            if (result > 0)
                System.out.println("new column added.");
            else
                System.out.println("unable to add a column.");
  
     //=================> closing statement and connection <===================\\
            stmt.close();
            con.close();
           }
        catch (SQLException err) {
                System.out.println( err.getMessage( ) );
           }
    }
}
