/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfor.the.presentation;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Adding_records {
    static final String host = "jdbc:derby://localhost:1527/DEMO";
    static final String uName = "demo";
    static final String uPass = "demo";
    
    public void InsertData(){
        
        try{

            Connection con = DriverManager.getConnection(host, uName, uPass);
            System.out.println("connection succeeded");
            
            Statement stmt = con.createStatement();		      
            // Execute a query
            System.out.println("Inserting records into the table...");
            
            String sql = "INSERT INTO DEMO VALUES (1, 'Zara', 'Ali', 'Farhan Akhtar' , 3.2)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO DEMO VALUES (2, 'Muhammad', 'Minhas', 'Abd ullah', 3.7)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO DEMO VALUES (3, 'Zaid', 'Khan', 'Zartaj Gul', 3.0)";
            stmt.executeUpdate(sql);
            sql = "INSERT INTO DEMO VALUES(4, 'Ubaid', 'Mengal','Jan Bash', 2.8)";
            stmt.executeUpdate(sql);
            System.out.println("Inserted records into the table...");   
            
            stmt.close();
            con.close();
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
    }
}
