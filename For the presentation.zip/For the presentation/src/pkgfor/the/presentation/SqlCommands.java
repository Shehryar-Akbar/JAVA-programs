/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkgfor.the.presentation;

/**
 *
 * @author Shehryar Akbar
 */
public class SqlCommands {
//    
//    -- INSERT INTO STUDENTINFO (ID, FIRST_NAME, LAST_NAME, F_NAME, GPA) 
//-- VALUES (5, 'Sharif', 'Danish', 'Jan Bash', 3.6);
//
//--DELETE FROM STUDENTINFO WHERE ID = 2;
//
//-- UPDATE STUDENTINFO
//-- SET FIRST_NAME = 'Ubaid', LAST_NAME = 'Ali Shah'
//-- WHERE ID = 4;
//
//SELECT * FROM STUDENTINFO;
}
