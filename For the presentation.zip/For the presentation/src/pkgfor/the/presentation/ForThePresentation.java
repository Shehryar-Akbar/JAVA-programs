package pkgfor.the.presentation;




public class ForThePresentation {
    public static void main(String[] args) {
        
//        Creating_column obj = new Creating_column();
//        obj.Column();
        
//        Adding_records obj2 = new Adding_records();
//        obj2.InsertData();

//        Retrieving_record obj3 = new Retrieving_record();
//        obj3.Taking_record();

//        Updating_record obj4 = new Updating_record();
//        obj4.Update();
            
    }
}
