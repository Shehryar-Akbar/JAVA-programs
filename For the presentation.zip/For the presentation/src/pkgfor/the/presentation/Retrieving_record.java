package pkgfor.the.presentation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Retrieving_record {
        static final String host = "jdbc:derby://localhost:1527/DEMO";
        static final String uName = "demo";
        static final String uPass = "demo";
        static final String QUERY = "SELECT * FROM DEMO";
    
    public void Taking_record(){
        
        try{

            Connection con = DriverManager.getConnection(host, uName, uPass);
            System.out.println("connection succeeded");
            
            Statement stmt = con.createStatement();
            
            ResultSet rs = stmt.executeQuery(QUERY);
            
            while(rs.next()){
            //Display values
            System.out.println("ID: " + rs.getInt("ID"));
            System.out.println("First_name: " + rs.getString("FIRST_NAME"));
            System.out.println("Last_name: " + rs.getString("LAST_NAME"));
            System.out.println("Father_name: " + rs.getString("F_NAME"));
            System.out.println("GPA: " + rs.getDouble("GPA"));
         }
            
            stmt.close();
            con.close();
        } 
        catch (SQLException e) {
            System.out.println(e);
        }
    }
}
