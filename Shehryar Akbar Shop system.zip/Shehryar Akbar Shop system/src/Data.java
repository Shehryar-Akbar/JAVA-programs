import java.util.Scanner;

public class Data {
	Scanner in = new Scanner(System.in);
	//------------------------ DISPLAY METHOD IT CONTAINS ALL THESE OTHER CLASSES ------------------------//
	public void dispaly() {
		System.out.println("Chose on the followig");
		System.out.print("1) To buy a book\n2) To issue book\n3) Information\n");
		int option = in.nextInt();
		//------------------- IF THIS IS TRUE THEN IT WILL TAKE DATA FOR BUYING THE BOOK ---------------------//
		if(option==1) {
			BuyBook book = new BuyBook(); //----------> CREATION OF OBJECT FROM THE CLASS BuyBook 
			book.buybook();      //---------------> Call to the buybook() method
			System.out.println();
			System.out.println("If you want to print a script for you press 1 or 0 to exit");
			int opt = in.nextInt();
			if(opt == 1) {
				book.display();
			}
			else if(opt == 0) {
				System.exit(0);	//-----------------> WILL EXIT THE PROGRAM <--------------------//
			}
		}
		//-----------------> IF THIS IS TRUE IT WILL ISSUE THE BOOK <------------------------//
		else if(option == 2) {
			IssueBook issuebook = new IssueBook();	//-----------------------> OBJECT OF THE BOOK <------------------//
			issuebook.data();	//------- call to data() method -----------//
			issuebook.amount();		//----------- call to amount method() ------------//
		}
		//----------------> IF THIS IS TRUE IT WILL TAKE THE USER TO THE INFORMATION <--------------------------//
		else if(option==3) {
			Information info = new Information();	//------------------> OBJECT OF THE CLASS Information <-----------------//
			info.data();
		}
	}
}
