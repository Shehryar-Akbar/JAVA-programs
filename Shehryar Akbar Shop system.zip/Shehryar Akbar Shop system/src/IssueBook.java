import java.util.*;
public class IssueBook {
	String BookName;
	int BookID;
	int numberofdays;
	long CNIC;
	
	Scanner in = new Scanner(System.in);
	//----------------------- DATA FOR ISSUING THE BOOK ---------------------//
	public void data() {
		System.out.print("Enter the name of the book: ");
		BookName = in.nextLine();
		System.out.print("Enter the ID of the book: ");
		BookID = in.nextInt();
		System.out.print("Enter your CNIC: ");
		CNIC = in.nextLong();
		System.out.print("Enter the number of days you want to : ");
		numberofdays = in.nextInt();
		//--------------------------------------------------------------------//
	}
	
	public void amount() {
		//------------------- FOR THE PRICE OF THE BOOK ----------------------//
		if(numberofdays>=1 && numberofdays<=10) {
			System.out.println("The payable amount is: 100");
		}
		else if(numberofdays>=11 && numberofdays<=20) {
			System.out.println("The payable amount is: 200");
		}
		if(numberofdays>=21 && numberofdays<=30) {
			System.out.println("The payable amount is: 300");
		}
		if(numberofdays>30) {
			System.out.println("I am sorry!! We can issue the book only from 1 to 30 days");
		}
		System.out.println("press 1 to go to main menu or 0 to exit");
		int opt = in.nextInt();
		if(opt==1) {
			Data maindata = new Data();
			maindata.dispaly();
		}
		else if(opt==0) {
			System.exit(0);
		}
		//---------------------------------------------------------------------//
	}
}
