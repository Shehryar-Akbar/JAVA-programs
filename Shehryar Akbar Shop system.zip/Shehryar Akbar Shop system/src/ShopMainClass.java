
public class ShopMainClass {

    public static void main(String[] args) {
        Data data = new Data();	//----------------------> this is the only object from class Data <-----------------//
	data.dispaly();		//------------------> call to the method inside the class Data <----------------------//
    }
    
}
