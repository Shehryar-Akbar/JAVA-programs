import java.util.*;
//--------------- MAIN CLASS ---------------------//
public class Information {
	Scanner in = new Scanner(System.in);
	Random rand = new Random();	//----------- RANDOM NUMBER GANERATOR  ------------//
	public void data() {
		System.out.println("1) People in shop\n2) About books\n3) Search a book");
		int option = in.nextInt();
		switch(option) {
			case 1:{
				//==================== MAIN MENUE ==================//
				System.out.println("Head of the shop is Muhammad Minhas");
				System.out.println("WORKERS");
				System.out.println("Shehryar Akbar");
				System.out.println("Ubaid Ali Shah");
				System.out.println("Amjad Ghafori");
				
				//============ GOING BACK TO MAIN MENU ==============//
				
				System.out.println("press 1 for main menu of 0 to exit");
				int opt = in.nextInt();
				if(opt==1) {
					Data data = new Data();
					data.dispaly();
				}
				else if(opt==0) {
					System.exit(0);
				}
				
				//===================================================//
			}
			case 2:{
				//=================== INFORMATION ABOUT WORKERS =========================//
				System.out.println("There are 200 books in our shop");
				System.out.println("These books are in the arranged in the alphabetic order");
				System.out.println("We hava book availabel in the following alphabets");
				System.out.println("A to H");
				//=========================================================//
				
				//============ GOING BACK TO MAIN MENU ==============//
				
				System.out.println("press 1 for main menu of 0 to exit");
				int opt = in.nextInt();
				if(opt==1) {
					Data data = new Data();
					data.dispaly();
				}
				else if(opt==0) {
					System.exit(0);
				}
				//==================================================//
			}
			case 3:{
				
				//===================== SEARCHING AREA FOR BOOK =====================//
				
				System.out.println("Please enter the alphabet in the capital for in the range from A to H");
				char ch = in.next().charAt(0);
				if(ch=='A'||ch=='B'||ch=='C'||ch=='D'||ch=='E'||ch=='F'||ch=='G'||ch=='H') {
					int num1 = 1 + rand.nextInt(10);
					System.out.println("Go and find your book in " + num1 + " number cupboard");
					int num2 = 1 + rand.nextInt(4);
					System.out.println("in "+num2+" partition");
					
				//===========================================================//
					
					//============ GOING BACK TO MAIN MENU ==============//
					
					System.out.println("press 1 for main menu of 0 to exit");
					int opt = in.nextInt();
					if(opt==1) {
						Data data = new Data();
						data.dispaly();
					}
					else if(opt==0) {
						System.exit(0);
					}
					//=================================================//
				}
			}
		}
	}	
}
