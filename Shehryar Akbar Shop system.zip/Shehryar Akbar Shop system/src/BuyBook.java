import java.util.*;
public class BuyBook {
	String BookName;
	int BookID;
	long BookPages;
	
	//=========== THIS IS FOR GENERATING THE PRICE OF THE BOOK RANDOMLY IN THE RANGE 200 TO 800 ===============//
	long BookPrice = (long) (Math.floor(Math.random() * (800-200)+1));
	
	Scanner in = new Scanner(System.in);	//========== FOR GETTING INPUT ============//
	
	//=========== FUNCTION FOR GETTING DATA FROM USER ==============//
	public void buybook() {
		System.out.print("Enter the name of the book: ");
		BookName = in.nextLine();
		System.out.print("Enter the ID of the book: ");
		BookID = in.nextInt();
		System.out.print("Enter pages of the book: ");
		BookPages = in.nextLong();
		System.out.println("Price of the book is: "+BookPrice);
	}
	
	//================ FUNCTION TO DISPLAY THE DATA TO THE CUSTOMER ==========================//
	public void display() {
		System.out.println("================================");
		System.out.println("Name of book: "+BookName);
		System.out.println("ID of the book is: "+BookID);
		System.out.println("Number of pages in the book: "+BookPages);
		System.out.println("Price of the book is: "+BookPrice);
		System.out.print("================================");
		System.out.println("press 1 for main menu or 0 to exit");
		int opt = in.nextInt();
		if(opt==1) {
			Data data = new Data();
			data.dispaly();
		}
		else if(opt==0) {
			System.exit(0);
		}	
	}
}
